

let nombre1 = "Maxwell Wright";
let nombre2 = "Raja Villareal";
let nombre3 = "Helen Richards ";
let telefono1 = "(0191)7196495";
let telefono2 = "0866 398 2895";
let telefono3 = "0800 1111";
let correo1 = "Curabitur.egestas.nun@nonummyac.co.uk" ; 
let correo2 = "posuere.vulputate@sed.com" ; 
let correo3 = "libero@convalis.edu" ;
        
console.log("Nombre : "+nombre1+", telefono : "+telefono1+" , correo : "+correo1);
console.log("Nombre : "+nombre2+", telefono : "+telefono2+" , correo : "+correo2);
console.log("Nombre : "+nombre3+", telefono : "+telefono3+" , correo : "+correo3);